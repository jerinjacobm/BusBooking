package com.vast.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import com.vast.vo.Bus;

public class BusService implements IBusDao {
	static Logger logger = Logger.getLogger("vast");
	static ResourceBundle rb = ResourceBundle.getBundle("vast");
	private static IBusDao dao = new BusService();

	private BusService() {

	}
	static {
		try {
			Class.forName(rb.getString("driver"));
			logger.debug("driver loaded successfully");
		} catch (ClassNotFoundException e) {
			logger.error(e.getMessage());
		}
	}
	public static IBusDao getDaoInstance() {
		return dao;
	}
	
	//

	public List<Bus> findBuses(String departure, String arrival) {

		List<Bus> buses = new ArrayList<>();

		return buses;
	}

	public List<String> getAvailableSeats(String busId) {

		List<String> seats = new ArrayList<>();
		seats.add("1A");
		seats.add("1B");
		seats.add("1C");
		return seats;
	}
}
