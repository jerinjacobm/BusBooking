package com.vast.exception;

public class NotFoundException {

}
