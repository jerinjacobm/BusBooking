package com.vast.exception;

public class AlreadyExistException {

}
